﻿
namespace MordorsCrueltyPlan.Moods
{
    class Angry : Mood
    {
        public Angry(int happinessPoints) : base (happinessPoints)
        {
        }
    }
}
