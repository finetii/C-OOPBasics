﻿
namespace MordorsCrueltyPlan.Moods
{
    class Happy : Mood
    {
        private int happinessPoints;
        public Happy(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
