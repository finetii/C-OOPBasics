﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MordorsCrueltyPlan.Moods
{
    class JavaScript : Mood
    {
        private int happinessPoints;

        public JavaScript(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
