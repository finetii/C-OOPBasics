﻿
namespace MordorsCrueltyPlan.Moods
{
    class Sad : Mood
    {
        private int happinessPoints;

        public Sad(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
