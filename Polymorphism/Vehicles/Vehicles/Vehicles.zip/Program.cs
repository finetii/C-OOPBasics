﻿using System;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(new char[] { ' ' },StringSplitOptions.RemoveEmptyEntries);
            double.TryParse(carInfo[1], out double carFuelQty);
            double.TryParse(carInfo[2],out double carFuelConsumption);
            string[] truckInfo = Console.ReadLine().Split(new char[] { ' ' },StringSplitOptions.RemoveEmptyEntries);
            double.TryParse(truckInfo[1], out double truckFuelQty);
            double.TryParse(truckInfo[2], out double truckFuelConsumption);

            Vehicle car = new Car(carFuelQty, carFuelConsumption);
            Vehicle truck = new Truck(truckFuelQty, truckFuelConsumption);

            int.TryParse(Console.ReadLine(), out int numberOfEntries);

            for (int i = 0; i < numberOfEntries; i++)
            {
                string[] command = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                switch (command[0])
                {
                    case "Drive":
                        double.TryParse(command[2], out double distance);
                        if (command[1] == "Car")
                        {
                            try
                            {
                                car.Drive(distance);
                                Console.WriteLine($"Car travelled {distance} km");
                            }
                            catch (ArgumentException ae)
                            {
                                Console.WriteLine(ae.Message);
                            }
                        }
                        else
                        {
                            try
                            {
                                truck.Drive(distance);
                                Console.WriteLine($"Truck travelled {distance} km");
                            }
                            catch (ArgumentException ae)
                            {
                                Console.WriteLine(ae.Message);
                            }
                        }
                        break;

                    case "Refuel":
                        double.TryParse(command[2], out double liters);
                        if (command[1] == "Car")
                        {
                            try
                            {
                                car.Refuel(liters);
                            }
                            catch (ArgumentException ae)
                            {
                                Console.WriteLine(ae.Message);
                            }
                        }
                        else
                        {
                            try
                            {
                                truck.Refuel(liters);
                            }
                            catch(ArgumentException ae)
                            {
                                Console.WriteLine(ae.Message);
                            }
                        }
                        break;
                }
            }
            Console.WriteLine($"Car: {car.FuelQty:f2}");
            Console.WriteLine($"Truck: {truck.FuelQty:f2}");
        }
    }
}
