﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class Truck : Vehicle
    {
        public Truck(double fuelQty, double fuelConsumption)
            : base (fuelQty, fuelConsumption)
        {
            this.FuelConsumption += 1.6;
        }

        public override void Drive(double distance)
        {
            if((distance * this.FuelConsumption) <= FuelQty)
            {
                this.FuelQty -= distance * this.FuelConsumption;
            }
            else
            {
                throw new ArgumentException("Truck needs refueling");
            }
        }

        public override void Refuel(double liters)
        {
            this.FuelQty += liters * 0.95;
        }
    }
}
