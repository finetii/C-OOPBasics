﻿
namespace Vehicles
{
    abstract class Vehicle
    {
        double fuelQty;
        double fuelConsumption;

        public double FuelQty
        {
            get { return fuelQty; }
            set { fuelQty = value; }
        }


        public double FuelConsumption
        {
            get { return fuelConsumption; }
            set { fuelConsumption = value; }
        }


        public Vehicle(double fuelQty, double fuelConsumption)
        {
            this.FuelQty = fuelQty;
            this.FuelConsumption = fuelConsumption;
        }

        public abstract void Drive(double distance);

        public virtual void Refuel(double liters)
        {
            this.FuelQty += liters;
        }
    }
}
